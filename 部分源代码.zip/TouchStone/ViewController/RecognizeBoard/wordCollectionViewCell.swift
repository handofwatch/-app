//
//  wordCollectionViewCell.swift
//  TouchStone
//
//  Created by 王星洲 on 2018/7/25.
//  Copyright © 2018 cn.edu.tongji.1652977. All rights reserved.
//

import UIKit

class wordCollectionViewCell: UICollectionViewCell {
    
    //中央显示的文字
    @IBOutlet weak var Wordlabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
