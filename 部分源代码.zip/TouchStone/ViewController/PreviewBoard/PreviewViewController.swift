//
//  PreviewViewController.swift
//  TouchStone
//
//  Created by 王星洲 on 2018/7/30.
//  Copyright © 2018 cn.edu.tongji.1652977. All rights reserved.
//

import UIKit

class PreviewViewController: UIViewController {
    
    @IBOutlet weak var imageVIew: UIImageView!
    
    @IBOutlet weak var shareButton: UIButton!
    
    var getImage : UIImage!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        shareButton.setBackgroundImage(UIImage(named: "Share"), for: UIControlState.normal)
        
        imageVIew.image = getImage
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func shareButtonTapped(_ sender: Any) {
        let myWeb = NSURL(string: "http://www.touchStone.com")
        let shareString = "一起来用触墨创造作品吧！"
        let activity = UIActivity()
        let activityItems = [getImage, shareString, myWeb as Any] as [Any]
        let activities = [activity]
        let activityController = UIActivityViewController(activityItems: activityItems,            applicationActivities: activities)
        activityController.excludedActivityTypes = [UIActivityType.copyToPasteboard,UIActivityType.assignToContact]
        self.present(activityController, animated: true, completion: {()-> Void in})
    }
    
    @IBAction func downloadButtonTapped(_ sender: Any) {
        UIGraphicsBeginImageContextWithOptions(self.imageVIew.frame.size,false,UIScreen.main.scale)
        
        self.imageVIew.layer.render(in:UIGraphicsGetCurrentContext()!)
        
        let image1 = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        //保存完后调用的方法
        let selector = #selector(PreviewViewController.onCompleteCapture(image:error:contextInfo:))
        //保存
        UIImageWriteToSavedPhotosAlbum(image1!, self, selector, nil)
    }
    
    @objc func onCompleteCapture(image: UIImage, error:NSError?, contextInfo: UnsafeRawPointer) {
        if error == nil {
            //保存成功
            let alertController1 = UIAlertController(title: "", message: "保存成功", preferredStyle: .alert)
            self.present(alertController1,animated: true,completion: nil)
            //显示一秒后自动消失
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                self.presentedViewController?.dismiss(animated: false, completion: nil)
            }
        }else {
            //保存失败
            let alertController2 = UIAlertController(title: "", message: "保存失败", preferredStyle: .alert)
            self.present(alertController2,animated: true,completion: nil)
            //显示一秒后自动消失
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                self.presentedViewController?.dismiss(animated: false, completion: nil)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "collectPaint"
        {
            let vc = segue.destination as! CollectionBoardViewController
            vc.getImage = getImage
        }
    }
    
    @IBAction func collectButtonTapped(_ sender: Any) {
        performSegue(withIdentifier: "collectPaint", sender: nil)
    }
    
    @IBAction func close(Segue:UIStoryboardSegue)
    {
    }
}
