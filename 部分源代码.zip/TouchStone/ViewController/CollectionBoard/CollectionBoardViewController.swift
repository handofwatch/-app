//
//  CollectionBoardViewController.swift
//  TouchStone
//
//  Created by 王星洲 on 2018/7/21.
//  Copyright © 2018 cn.edu.tongji.1652977. All rights reserved.
//

import UIKit

class CollectionBoardViewController: UIViewController,UICollectionViewDataSource, UICollectionViewDelegate {
    
    var getImage:UIImage!
    
    var attirbute = [false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false]
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.register(UINib.init(nibName: "GalleryCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "GalleryIdentifier")
        //设置CollectionView格式
        let flowLayout = UPCarouselFlowLayout()
        flowLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width / 2, height: collectionView.frame.size.height / 3 )
        flowLayout.scrollDirection = .vertical
        flowLayout.sideItemScale = 1
        flowLayout.sideItemAlpha = 1
        flowLayout.spacingMode = .fixed(spacing: 20.0)
        
        //为HomeCollectionView添加格式、数据源和代理
        collectionView.collectionViewLayout = flowLayout
        collectionView.delegate=self
        collectionView.dataSource=self
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GalleryIdentifier", for: indexPath) as! GalleryCollectionViewCell
        
        //        cell.image.image = getImage
        
        return cell
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //返回方法
    @IBAction func close(Segue:UIStoryboardSegue)
    {
        
    }
}
