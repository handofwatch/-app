//
//  DecorateViewController.swift
//  TouchStone
//
//  Created by 王星洲 on 2018/7/29.
//  Copyright © 2018 cn.edu.tongji.1652977. All rights reserved.
//

import UIKit

class DecorateViewController: UIViewController {
    
    @IBOutlet weak var selectToolBar: UIToolbar!
    
    @IBOutlet weak var backButton: UIButton!
    
    @IBOutlet weak var viewButton: UIButton!
    
    @IBOutlet weak var upSelectBar: UIToolbar!
    
    @IBOutlet weak var upBanshiButton: UIBarButtonItem!
    
    @IBOutlet weak var upZhizhangButton: UIBarButtonItem!
    
    @IBOutlet weak var upZhuangshiButton: UIBarButtonItem!
    
    @IBOutlet weak var upYinzhangButton: UIBarButtonItem!
    
    @IBOutlet weak var banshiButton: UIBarButtonItem!
    
    @IBOutlet weak var zhizhangButton: UIBarButtonItem!
    
    @IBOutlet weak var zhuangshiButton: UIBarButtonItem!
    
    @IBOutlet weak var yinzhangButton: UIBarButtonItem!
    
    @IBOutlet weak var finalView: UIView!
    
    @IBOutlet weak var backgroundImage: UIImageView!
    
    @IBOutlet weak var borderImage: UIImageView!
    
    @IBOutlet weak var wordView: UIView!
    
    @IBOutlet weak var wordLabel: UILabel!
    
    @IBOutlet weak var poemTextView: UITextView!
    
    @IBOutlet weak var sealImage: UIImageView!
    
    @IBOutlet weak var decorateView: UIImageView!
    
    var paintedImage: UIImage!
    
    var order : Int!
    
    var getWord : String!
    
    var ImageView : UIImageView!
    
    var selectOrder : Int!
    
    var isUpSelectorShowed : Bool!
    
    //TODO::设置诗句
    func changePoem(word:String)->String
    {
        switch(word)
        {
        case"墨":
            return "这是墨的诗"
        case"书":
            return "这是书的诗"
        case"笔":
            return "这是笔的诗"
        case"真":
            return "这是真的诗"
        case"情":
            return "这是情的诗"
        default:
            return "这个字我们没有收录"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        isUpSelectorShowed = false
        
        upBanshiButton.setBackgroundImage(UIImage(named: "2-3_版式"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        upBanshiButton.tintColor = UIColor.clear
        banshiButton.setBackgroundImage(UIImage(named: "2-3_版式"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        banshiButton.tintColor = UIColor.clear
        banshiButton.action = #selector(n1ButtonClicked(sender:))
        
        upZhizhangButton.setBackgroundImage(UIImage(named: "2-3_纸张"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        upZhizhangButton.tintColor = UIColor.clear
        zhizhangButton.setBackgroundImage(UIImage(named: "2-3_纸张"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        zhizhangButton.tintColor = UIColor.clear
        zhizhangButton.action = #selector(n2ButtonClicked(sender:))
        
        upZhuangshiButton.setBackgroundImage(UIImage(named: "2-3_装饰"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        upZhuangshiButton.tintColor = UIColor.clear
        zhuangshiButton.setBackgroundImage(UIImage(named: "2-3_装饰"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        zhuangshiButton.tintColor = UIColor.clear
        zhuangshiButton.action = #selector(n3ButtonClicked(sender:))
        
        upYinzhangButton.setBackgroundImage(UIImage(named: "2-3_印章"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        upYinzhangButton.tintColor = UIColor.clear
        yinzhangButton.setBackgroundImage(UIImage(named: "2-3_印章"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        yinzhangButton.tintColor = UIColor.clear
        yinzhangButton.action = #selector(n4ButtonClicked(sender:))
        
        poemTextView.text = changePoem(word: getWord)
        
        self.view.bringSubview(toFront: selectToolBar)
        self.view.bringSubview(toFront: viewButton)
        self.view.bringSubview(toFront: backButton)
        self.view.sendSubview(toBack: upSelectBar)
        
        switch order
        {
        case -1:
            
            //            paintedImage = paintedImage.reSizeImage(reSize: CGSize(width: wordView.frame.size.width, height: wordView.frame.size.height))
            ImageView = UIImageView(frame: CGRect(x: wordView.frame.minX, y: wordView.frame.minY, width: wordView.frame.size.width, height: wordView.frame.size.height))
            //            print(wordView.frame.midX,wordView.frame.midY,wordView.frame.size.width,wordView.frame.size.height)
            ImageView.image = paintedImage
            self.wordView.addSubview(ImageView)
            wordLabel.text = ""
        case 0:
            wordLabel.text = getWord
        //TODO::fontFamily字体改变
        case 1:
            wordLabel.text = getWord
        case 2:
            wordLabel.text = getWord
        case 3:
            wordLabel.text = getWord
        case 4:
            wordLabel.text = getWord
        case 5:
            wordLabel.text = getWord
        case 6:
            wordLabel.text = getWord
        case 7:
            wordLabel.text = getWord
        case 8:
            wordLabel.text = getWord
        case 9:
            wordLabel.text = getWord
        default:
            print("Wrong")
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        UIGraphicsBeginImageContext(CGSize(width: self.finalView.bounds.size.width,
                                           height: self.finalView.bounds.size.height))
        self.finalView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        print("getImage!")
        
        if segue.identifier == "GoPreview"
        {
            let vc = segue.destination as! PreviewViewController
            vc.getImage = image
        }
    }
    
    @objc func n1ButtonClicked(sender: UIBarButtonItem)
    {
        if isUpSelectorShowed == false
        {
            selectOrder = 1
            self.view.bringSubview(toFront: upSelectBar)
            banshiButton.setBackgroundImage(UIImage(named: "边框1")?.scaleImage(scaleSize: 0.1), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            zhizhangButton.setBackgroundImage(UIImage(named: "边框2")?.scaleImage(scaleSize: 0.1), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            zhuangshiButton.setBackgroundImage(UIImage(named: "边框3")?.scaleImage(scaleSize: 0.1), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            yinzhangButton.setBackgroundImage(UIImage(named: "3_add"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            isUpSelectorShowed = true
        }
        else
        {
            switch selectOrder
            {
            case 1:
                borderImage.image = UIImage(named: "边框1")
            case 2:
                backgroundImage.image = UIImage(named: "1-白色宣纸")
            case 3:
                decorateView.image = UIImage(named: "装饰-圆")
            case 4:
                sealImage.image = UIImage(named: "pic1")
            default:
                print("Wrong!")
            }
            self.view.sendSubview(toBack: upSelectBar)
            isUpSelectorShowed = false
            banshiButton.setBackgroundImage(UIImage(named: "2-3_版式"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            zhizhangButton.setBackgroundImage(UIImage(named: "2-3_纸张"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            zhuangshiButton.setBackgroundImage(UIImage(named: "2-3_装饰"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            yinzhangButton.setBackgroundImage(UIImage(named: "2-3_印章"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        }
    }
    
    @objc func n2ButtonClicked(sender: UIBarButtonItem)
    {
        if isUpSelectorShowed == false
        {
            selectOrder = 2
            self.view.bringSubview(toFront: upSelectBar)
            banshiButton.setBackgroundImage(UIImage(named: "1-白色宣纸")?.scaleImage(scaleSize: 0.1), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            zhizhangButton.setBackgroundImage(UIImage(named: "2-浅黄色")?.scaleImage(scaleSize: 0.1), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            zhuangshiButton.setBackgroundImage(UIImage(named: "5-柳叶纸")?.scaleImage(scaleSize: 0.1), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            yinzhangButton.setBackgroundImage(UIImage(named: "3_add"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            isUpSelectorShowed = true
        }
        else
        {
            switch selectOrder
            {
            case 1:
                borderImage.image = UIImage(named: "边框2")
            case 2:
                backgroundImage.image = UIImage(named: "2-浅黄色")
            case 3:
                decorateView.image = UIImage(named: "装饰-山")
            case 4:
                sealImage.image = UIImage(named: "pic2")
            default:
                print("Wrong!")
            }
            self.view.sendSubview(toBack: upSelectBar)
            isUpSelectorShowed = false
            banshiButton.setBackgroundImage(UIImage(named: "2-3_版式"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            zhizhangButton.setBackgroundImage(UIImage(named: "2-3_纸张"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            zhuangshiButton.setBackgroundImage(UIImage(named: "2-3_装饰"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            yinzhangButton.setBackgroundImage(UIImage(named: "2-3_印章"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        }
    }
    
    @objc func n3ButtonClicked(sender: UIBarButtonItem)
    {
        if isUpSelectorShowed == false
        {
            selectOrder = 3
            self.view.bringSubview(toFront: upSelectBar)
            banshiButton.setBackgroundImage(UIImage(named: "装饰-圆")?.scaleImage(scaleSize: 0.3), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            zhizhangButton.setBackgroundImage(UIImage(named: "装饰-山")?.scaleImage(scaleSize: 0.2), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            zhuangshiButton.setBackgroundImage(UIImage(named: "装饰-鲤")?.scaleImage(scaleSize: 0.4), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            yinzhangButton.setBackgroundImage(UIImage(named: "3_add"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            isUpSelectorShowed = true
        }
        else
        {
            switch selectOrder
            {
            case 1:
                borderImage.image = UIImage(named: "边框3")
            case 2:
                backgroundImage.image = UIImage(named: "5-柳叶纸")
            case 3:
                decorateView.image = UIImage(named: "装饰-鲤")
            case 4:
                sealImage.image = UIImage(named: "pic3")
            default:
                print("Wrong!")
            }
            self.view.sendSubview(toBack: upSelectBar)
            isUpSelectorShowed = false
            banshiButton.setBackgroundImage(UIImage(named: "2-3_版式"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            zhizhangButton.setBackgroundImage(UIImage(named: "2-3_纸张"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            zhuangshiButton.setBackgroundImage(UIImage(named: "2-3_装饰"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            
            yinzhangButton.setBackgroundImage(UIImage(named: "2-3_印章"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
        }
    }
    @objc func n4ButtonClicked(sender: UIBarButtonItem)
    {
        if isUpSelectorShowed == false
        {
            selectOrder = 4
            self.view.bringSubview(toFront: upSelectBar)
            banshiButton.setBackgroundImage(UIImage(named: "pic1")?.scaleImage(scaleSize: 0.7), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            zhizhangButton.setBackgroundImage(UIImage(named: "pic2")?.scaleImage(scaleSize: 0.7), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            zhuangshiButton.setBackgroundImage(UIImage(named: "pic3")?.scaleImage(scaleSize: 0.7), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            yinzhangButton.setBackgroundImage(UIImage(named: "3_add"), for: UIControlState.normal, barMetrics: UIBarMetrics.default)
            isUpSelectorShowed = true
        }
        else
        {
            
        }
    }
    
    
    @IBAction func close(Segue:UIStoryboardSegue)
    {
    }
}
