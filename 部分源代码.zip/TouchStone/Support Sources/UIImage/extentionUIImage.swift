//
//  extentionUIImage.swift
//  TouchStone
//
//  Created by 王星洲 on 2018/7/30.
//  Copyright © 2018 cn.edu.tongji.1652977. All rights reserved.
//

import UIKit

extension UIImage
{
//    //返回一个将黑色背景变透明的UIImage
//    func imageByRemoveBlackBg() -> UIImage? {
//        let colorMasking: [CGFloat] = [0, 32, 0, 32, 0, 32]
//        return transparentColor(colorMasking: colorMasking)
//    }
//
//    func transparentColor(colorMasking:[CGFloat]) -> UIImage? {
//        if let rawImageRef = self.cgImage {
//            UIGraphicsBeginImageContext(self.size)
//            if let maskedImageRef = rawImageRef.copy(maskingColorComponents: colorMasking) {
//                let context: CGContext = UIGraphicsGetCurrentContext()!
//                context.translateBy(x: 0.0, y: self.size.height)
//                context.scaleBy(x: 1.0, y: -1.0)
//                context.draw(maskedImageRef, in: CGRect(x:0, y:0, width:self.size.width,
//                                                        height:self.size.height))
//                let result = UIGraphicsGetImageFromCurrentImageContext()
//                UIGraphicsEndImageContext()
//                return result
//            }
//        }
//        return nil
//    }
    /**
     *  重设图片大小
     */
    func reSizeImage(reSize:CGSize)->UIImage {
        //UIGraphicsBeginImageContext(reSize);
        UIGraphicsBeginImageContextWithOptions(reSize,false,UIScreen.main.scale);
        self.draw(in: CGRect(x:0, y:0, width:reSize.width, height:reSize.height))
        let reSizeImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!;
        UIGraphicsEndImageContext();
        return reSizeImage;
    }
    
    /**
     *  等比率缩放
     */
    func scaleImage(scaleSize:CGFloat)->UIImage {
        let reSize = CGSize(width: self.size.width * scaleSize, height: self.size.height * scaleSize)
        return reSizeImage(reSize: reSize)
    }
}
